﻿using System;
using TechTalk.SpecFlow;

namespace APITesting.ContextHelper
{
  public  class ScenarioContextHelper
    {
        public static T GetContextObject<T>(string name)
        {
            if (ScenarioContext.Current.ContainsKey(name))
            {
                return (T)ScenarioContext.Current[name];
            }

            return default(T);
        }

        public static T GetContextObject<T>(Enum name)
        {
            return GetContextObject<T>(name.ToString());
        }

        public static void SetContextObject<T>(string name, T value)
        {
            if (ScenarioContext.Current.ContainsKey(name))
            {
                ScenarioContext.Current.Remove(name);
            }

            ScenarioContext.Current.Add(name, value);
        }

        public static void SetContextObject<T>(Enum name, T value)
        {
            SetContextObject(name.ToString(), value);
        }

        public static void DeleteContextObject(string name)
        {
            if (ScenarioContext.Current.ContainsKey(name))
            {
                ScenarioContext.Current.Remove(name);
            }
        }
    }
}
