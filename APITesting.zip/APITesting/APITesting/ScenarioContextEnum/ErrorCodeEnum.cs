﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APITesting.ScenarioContextEnum
{
  public enum ErrorCodeEnum
    {
        ERROR_MISSINGSTORE,
        ERROR_MISSINGLANGUAGE,
        ERROR_MISSINGCURRENCY,
        ERROR_MISSINGQUERY,
        ERROR_INVALIDSTORE,
        ERROR_INVALIDLANGUAGE,
        ERROR_INVALIDCURRENCYLENGTH,
    }
}
