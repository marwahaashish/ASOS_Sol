﻿using System;
using TechTalk.SpecFlow;

namespace APITesting
{
    using ContextHelper;
    using RestSharp;

    [Binding]
    public class CommonSteps : BaseSteps
    {
        [When(@"I get the response back from API")]
        public void WhenIGetTheResponseBackFromApi()
        {
            this.Response = this.Client.Execute<dynamic>(ScenarioContext.Current.Get<IRestRequest>(RequestKey));
            ScenarioContext.Current.Add(ResponseKey, this.Response);
        }

        [When(@"I get the response back from API with errorcode")]
        public void WhenIGetTheResponseBackFromAPIWithErrorcode()
        {

            this.Response = this.Client.Execute<dynamic>(ScenarioContext.Current.Get<IRestRequest>(RequestKey));
            var errorresponse = this.Response.Data[0];
            ScenarioContextHelper.SetContextObject<IRestResponse>(ResponseKey, this.Response);

            ErrorResponse res = new ErrorResponse();
            res.errorCode = errorresponse.errorCode;
            res.message = errorresponse.message;
            ScenarioContextHelper.SetContextObject<ErrorResponse>(DataKey, res);
        }
    }
}


