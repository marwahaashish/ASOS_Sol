﻿using APITesting.ScenarioContextEnum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APITesting
{
    class ErrorResponse
    {
        public ErrorCodeEnum errorCode { get; set; }
        public string message { get; set; }
    }
}
